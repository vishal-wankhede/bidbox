@php
    $configData = Helper::appClasses();
@endphp

@extends('layouts/layoutMaster')

@section('title', 'Archived Campaign List - Pages')

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/datatables-checkboxes-jquery/datatables.checkboxes.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/select2/select2.css') }}" />
    <link rel="stylesheet" href="{{ asset('assets/vendor/libs/@form-validation/umd/styles/index.min.css') }}" />

@endsection

@section('vendor-script')
    <script src="{{ asset('assets/vendor/libs/moment/moment.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/select2/select2.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/@form-validation/umd/bundle/popular.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/@form-validation/umd/plugin-bootstrap5/index.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/@form-validation/umd/plugin-auto-focus/index.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/cleavejs/cleave.js') }}"></script>
    <script src="{{ asset('assets/vendor/libs/cleavejs/cleave-phone.js') }}"></script>
@endsection


@section('content')
    <div class="card-datatable pt-0">
        <div class="card-header mb-3">
            <h5 class="card-title">Archived Campaign List</h5>
        </div>
        <div class="table-responsive" style="overflow-x: auto;">
            <table class="table table-bordered nowrap" id="users-table" style="width:100%;">
                <thead class="table-light">
                    <tr>
                        <th>Campaign Name</th>
                        <th>Brand</th>
                        <th>Status</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Impressions</th>
                        <th>CTR</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Campaign 1</td>
                        <td>Brand A</td>
                        <td>Active</td>
                        <td>2023-01-01</td>
                        <td>2023-12-31</td>
                        <td>10000</td>
                        <td>5%</td>
                        <td>
                            <a href="#"><i class="mdi mdi-archive-outline me-2"></i></a>
                            <a href="#"><i class="mdi mdi-delete-outline me-2"></i></a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
@endsection

@section('page-script')
    <script>
        $(function() {
            $('#users-table').DataTable({
                scrollX: true,
                responsive: false, // Turn off responsive to avoid row wrapping
                autoWidth: false,
                columnDefs: [{
                        targets: 0,
                        width: '200px'
                    }, // Campaign Name
                    {
                        targets: 1,
                        width: '150px'
                    },
                    {
                        targets: 7,
                        orderable: false
                    } // Actions
                ]
            });
        });
    </script>
@endsection
