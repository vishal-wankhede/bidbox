<?php

namespace App\Http\Controllers;

use App\Models\AgeRange;
use App\Models\Campaign;
use App\Models\CampaignCreative;
use App\Models\Country;
use App\Models\Filter;
use App\Models\FilterValue;
use App\Models\Gender;
use App\Models\Location;
use App\Models\LocationDetail;
use App\Models\Permission;
use Faker\Core\File;
use Faker\Provider\ar_EG\Person;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CampaignController extends Controller
{
  //
  public function index(Request $request)
  {
    // Logic to retrieve and display campaigns
    return view('content.pages.campaignlist', [
      'campaigns' => [],
    ]);
  }

  public function getarchive(Request $request)
  {
    return view('content.pages.archivedcampaign');
  }

  public function add(Request $request)
  {
    $data['locations'] = Location::where('parent', null)->get();
    $data['filters'] = Filter::where('parent_id', null)
      ->where('child', 0)
      ->orderBy('filter_order')
      ->get();
    $data['divisions'] = Filter::where('parent_id', null)
      ->where('child', 1)
      ->get();
    return view('content.pages.addcampaign', $data);
  }

  public function store(Request $request)
  {
    return $request->all();
    $validated = $request->validate([
      'campaign_name' => 'required|string|max:255',
      'brand_name' => 'required|string|max:255',
      'channel' => 'required|string',
      'impressions' => 'required|integer|min:1',
      'ctr' => 'nullable|numeric',
      'vtr' => 'nullable|numeric',
      'start_date' => 'required|date',
      'end_date' => 'required|date|after_or_equal:start_date',
      'brand_logo' => 'nullable|file|mimes:jpg,jpeg,png,svg|max:2048',
      'creative_files.*' => 'nullable|file|mimes:jpg,jpeg,png,gif,mp4|max:10000',
    ]);

    // ✅ Brand Logo Upload
    $logoPath = null;
    if ($request->hasFile('brand_logo')) {
      $logoFile = $request->file('brand_logo');
      $logoName =
        time() .
        '-' .
        Str::slug(pathinfo($logoFile->getClientOriginalName(), PATHINFO_FILENAME)) .
        '.' .
        $logoFile->getClientOriginalExtension();
      $logoFile->move(public_path('uploads/brand_logos'), $logoName);
      $logoPath = 'uploads/brand_logos/' . $logoName;
    }

    // ✅ Store Campaign
    $campaign = Campaign::create([
      'campaign_name' => $request->campaign_name,
      'campaign_description' => $request->campaign_description,
      'brand_name' => $request->brand_name,
      'brand_logo' => $logoPath,
      'channel' => $request->channel,
      'impressions' => $request->impressions,
      'ctr' => $request->ctr,
      'vtr' => $request->vtr,
      'start_date' => $request->start_date,
      'end_date' => $request->end_date,
      'projection_details' => json_decode($request->projection_details, true),
      'locations' => $request->locations ?? [],
      'gender' => $request->gender ?? [],
      'filtervalues' => $request->filtervalues ?? [],
      'division_value' => $request->division_value ?? [],
    ]);

    // ✅ Store Creatives
    $creativeMetas = $request->creatives ?? []; // from JS

    if ($request->hasFile('creative_files')) {
      $files = $request->file('creative_files');

      foreach ($files as $i => $file) {
        $fileName =
          time() .
          '-' .
          Str::slug(pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME)) .
          '.' .
          $file->getClientOriginalExtension();
        $file->move(public_path('uploads/creatives'), $fileName);

        // Get matching creative metadata (from hidden fields)
        $meta = $creativeMetas[$i] ?? [];

        CampaignCreative::create([
          'campaign_id' => $campaign->id,
          'file_name' => $file->getClientOriginalName(),
          'file_path' => 'uploads/creatives/' . $fileName,
          'file_type' => $meta['type'] ?? 'Unknown',
          'dimensions' => $meta['dimensions'] ?? null,
          'size' => $meta['size'] ?? null,
          'percentage' => $meta['percentage'] ?? 0,
        ]);
      }
    }

    return redirect()
      ->back()
      ->with('success', 'Campaign and creatives saved.');
  }

  public function archive(Request $request, $id)
  {
    // Logic to archive a campaign
    // Find the campaign by ID and update its status
    return redirect()->back();
  }

  public function destroy(Request $request, $id)
  {
    // Logic to delete a campaign
    // Find the campaign by ID and delete it
    return redirect()->back();
  }

  public function getTargetAudience(Request $request)
  {
    // return $request->all();
    $LocationDetails = LocationDetail::query();

    if (!empty($request->locations)) {
      // 1. Location Filter
      $requested = $request->locations ?? []; // array of selected location IDs
      $final = [];

      foreach ($requested as $locId) {
        $hasChildInRequest = Location::where('parent', $locId)
          ->whereIn('id', $requested)
          ->exists();

        if (!$hasChildInRequest) {
          $final[] = (int) $locId;
        }
      }

      $arr_final = array_values(array_unique($final)); // final array without parent if child exists

      $LocationDetails->where(function ($query) use ($arr_final) {
        foreach ($arr_final as $val) {
          $query->orWhereRaw('FIND_IN_SET(?, parent_locations)', [$val]);
        }
      });
    }
    // 2. Gender Filter
    if (!empty($request->gender)) {
      $LocationDetails->where(function ($query) use ($request) {
        foreach ($request->gender as $val) {
          $query->orWhereRaw('FIND_IN_SET(?, gender_id)', [$val]);
        }
      });
    }

    if (!empty($request->filters)) {
      $inputFilters = collect($request->filters);

      // Step 1: Extract and prepare filter_id → values mapping
      $filterValueMap = $inputFilters->mapWithKeys(function ($item) {
        return [(int) $item['filter_id'] => array_map('intval', $item['values'] ?? [])];
      });

      $filterIds = $filterValueMap->keys();

      // Step 2: Fetch filter metadata sorted by filter_order
      $filtersMeta = Filter::whereIn('id', $filterIds)
        ->orderBy('filter_order')
        ->get(['id', 'filter_order']);

      // Step 3: Rebuild the array in order (filter_id → values)
      $orderedFilters = $filtersMeta
        ->map(function ($filter) use ($filterValueMap) {
          return [
            'filter_id' => $filter->id,
            'values' => $filterValueMap[$filter->id] ?? [],
          ];
        })
        ->values();

      // Step 4: Merge all values in correct order
      $allValues = $orderedFilters
        ->pluck('values') // get collection of arrays
        ->flatten() // flatten to single array
        ->values(); // reindex

      // Step 5: Split into all-but-last and last
      $last_val = $allValues->pop(); // removes and returns last element
      $values = $allValues->toArray(); // remaining values

      $LocationDetails->where('filter_value_id', $last_val)->where(function ($query) use ($values) {
        foreach ($values as $val) {
          $query->orWhereRaw('FIND_IN_SET(?, parent_detail_id)', [$val]);
        }
      });
    }

    $population = $LocationDetails->sum('population_value');

    return response()->json([
      'population' => $population,
      'status' => 200,
    ]);
  }
}
