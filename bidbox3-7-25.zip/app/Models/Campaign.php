<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
  protected $fillable = [
    'campaign_name',
    'campaign_description',
    'brand_name',
    'brand_logo',
    'channels',
    'projection_type',
    'projection_number',
    'projection_daily_limit',
    'campaign_daily_limit',
    'start_date',
    'end_date',
    'projection_details',
    'min_age',
    'max_age',
    'age_allocation',
    'gender',
    'country_allocation',
    'state_allocation',
    'city_allocation',
    'device_type_percent',
    'device_models',
    'device_model_percent',
    'telecom_percent',
    'traffic_percent',
    'creative_file',
    'creative_percent',
    'inventory_percent',
    'cohort_percent',
  ];

  protected $casts = [
    'channels' => 'array',
    'projection_type' => 'array',
    'projection_number' => 'array',
    'projection_daily_limit' => 'array',
    'projection_details' => 'array',
    'min_age' => 'array',
    'max_age' => 'array',
    'age_allocation' => 'array',
    'gender' => 'array',
    'country_allocation' => 'array',
    'state_allocation' => 'array',
    'city_allocation' => 'array',
    'device_type_percent' => 'array',
    'device_models' => 'array',
    'device_model_percent' => 'array',
    'telecom_percent' => 'array',
    'traffic_percent' => 'array',
    'creative_percent' => 'array',
    'inventory_percent' => 'array',
    'cohort_percent' => 'array',
  ];

  public function creatives()
  {
    return $this->hasMany(CampaignCreative::class);
  }
}
