<?php

namespace App\Http\Controllers;

use App\Models\Campaign;
use App\Models\Filter;
use App\Models\FilterValue;
use App\Models\Location;
use Illuminate\Http\Request;
use App\Models\ReportLog;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

use function PHPSTORM_META\map;

class AnalyticsController extends Controller
{
  public function index(Request $request)
  {
    $data = [];

    // Campaign selected
    if ($request->campaign && $request->campaign !== 'Select Campaign') {
      $campaign = Campaign::find($request->campaign);
      $report = ReportLog::where('campaign_id', $request->campaign);

      // Filter by location if selected
      if ($request->location && $request->location !== 'Select Location') {
        $report = $report->where('locations', 'like', '%' . $request->location . '%');
      }

      // Filter by report type (hourly/daily)
      if ($request->type && $request->type !== 'Select Type') {
        $report = $report->where('report_type', $request->type);
      } else {
        $report = $report->where('report_type', 'daily');
      }

      $report = $report->orderBy('created_at', 'asc')->get();

      if ($report->isEmpty()) {
        return redirect()
          ->back()
          ->with('error', 'No report found for this campaign.');
      }
      $dates = $report
        ->pluck('created_at')
        ->map(function ($date) {
          return Carbon::parse($date)->format('d/m');
        })
        ->unique();
      $campaignctr = $report
        ->map(function ($item) {
          return $item->impressions > 0 ? round(($item->clicks / $item->impressions) * 100, 2) : 0;
        })
        ->toArray();

      $campaignvtr = $report
        ->map(function ($item) {
          return $item->impressions > 0 ? round(($item->video_views / $item->impressions) * 100, 2) : 0;
        })
        ->toArray();

      $ageRangeFilter = Filter::where('title', 'Age Range')->first();
      $deviceFilter = Filter::where('title', 'Device')->first();
      $filters = $report->pluck('filter_values')->toArray();
      $ageRangeArray = [];
      $deviceArray = [];
      foreach ($filters as $key => $filter) {
        if (isset($filter[$ageRangeFilter->id])) {
          foreach ($filter[$ageRangeFilter->id] as $ageKeyid => $ageValue) {
            $ageKey = FilterValue::where('id', $ageKeyid)->value('title');
            if (!$ageKey) {
              continue; // Skip if ageKey is not found
            }
            if (isset($ageRangeArray[$ageKey])) {
              $ageRangeArray[$ageKey] += $ageValue;
            } else {
              $ageRangeArray[$ageKey] = $ageValue;
            }
          }
        }

        if (isset($filter[$deviceFilter->id])) {
          foreach ($filter[$deviceFilter->id] as $deviceKeyid => $deviceValue) {
            $deviceKey = FilterValue::where('id', $deviceKeyid)->value('title');
            if (!$deviceKey) {
              continue; // Skip if deviceKey is not found
            }
            if (isset($deviceArray[$deviceKey])) {
              $deviceArray[$deviceKey] += $deviceValue;
            } else {
              $deviceArray[$deviceKey] = $deviceValue;
            }
          }
        }
      }

      $gender_array = [];
      $genders = $report->pluck('gender')->toArray();
      foreach ($genders as $gender) {
        foreach ($gender as $keyid => $value) {
          if ($keyid == 1) {
            $key = 'male';
          } elseif ($keyid == 2) {
            $key = 'female';
          } elseif ($keyid == 3) {
            $key = 'other';
          } else {
            $key = 'unknown';
          }
          if (isset($gender_array[$key])) {
            $gender_array[$key] += $value;
          } else {
            $gender_array[$key] = $value;
          }
        }
      }
      $totalGender = array_sum($gender_array);
      $genderRatios = [];

      foreach ($gender_array as $key => $value) {
        $genderRatios[$key] = $totalGender > 0 ? round(($value / $totalGender) * 100) : 0;
      }

      $locations = $report->pluck('locations')->toArray();
      $locationArray = [];
      foreach ($locations as $location) {
        foreach ($location as $keyid => $value) {
          $locationKey = Location::where('id', $keyid)->value('name');
          if (!$locationKey) {
            continue; // Skip if locationKey is not found
          }
          if (isset($locationArray[$locationKey])) {
            $locationArray[$locationKey] += $value;
          } else {
            $locationArray[$locationKey] = $value;
          }
        }
      }

      $InventoryFilter = Filter::where('title', 'Inventories')->first();
      $CohortFilter = Filter::where('title', 'Cohorts')->first();
      $filters1 = $report->pluck('division_values')->toArray();
      $InventoryArray = [];
      $CohortArray = [];
      foreach ($filters1 as $key => $filter) {
        if (isset($filter[$InventoryFilter->id])) {
          foreach ($filter[$InventoryFilter->id] as $inventoryKeyid => $inventoryValue) {
            $inventoryKey = FilterValue::where('id', $inventoryKeyid)->value('title');
            if (!$inventoryKey) {
              continue; // Skip if inventoryKey is not found
            }
            if (isset($InventoryArray[$inventoryKey])) {
              $InventoryArray[$inventoryKey] += $inventoryValue;
            } else {
              $InventoryArray[$inventoryKey] = $inventoryValue;
            }
          }
        }

        if (isset($filter[$CohortFilter->id])) {
          foreach ($filter[$CohortFilter->id] as $CohortKeyid => $CohortValue) {
            $CohortKey = FilterValue::where('id', $CohortKeyid)->value('title');
            if (!$CohortKey) {
              continue; // Skip if CohortKey is not found
            }
            if (isset($CohortArray[$CohortKey])) {
              $CohortArray[$CohortKey] += $CohortValue;
            } else {
              $CohortArray[$CohortKey] = $CohortValue;
            }
          }
        }
      }

      // Build report summary
      $data['report'] = [
        'impressions' => $report->sum('impressions'),
        'clicks' => $report->sum('clicks'),
        'video_views' => $report->sum('video_views'),
        'ctr' => $campaign->ctr,
        'vtr' => $campaign->vtr,
        'ctr_arr' => $campaignctr,
        'vtr_arr' => $campaignvtr,
        'impression_daily' => json_encode($report->pluck('impressions')->toArray()),
        'clicks_daily' => json_encode($report->pluck('clicks')->toArray()),
        'video_views_daily' => json_encode($report->pluck('video_views')->toArray()),
        'dateLabels' => json_encode($dates->toArray()),
        'dateLabels_arr' => $dates->toArray(),
        'ageRange' => $ageRangeArray,
        'device' => $deviceArray,
        'gender' => $genderRatios,
        'locations' => $locationArray,
        'inventories' => $InventoryArray,
        'cohorts' => $CohortArray,
      ];
    } else {
      // Default report if no campaign selected
      $data['report'] = [
        'impressions' => 0,
        'clicks' => 0,
        'video_views' => 0,
        'ctr' => 0,
        'ctr_arr' => [0],
        'vtr' => 0,
        'vtr_arr' => [0],
        'impression_daily' => json_encode([0]),
        'clicks_daily' => json_encode([0]),
        'video_views_daily' => json_encode([0]),
        'dateLabels' => json_encode(['No Data']),
        'dateLabels_arr' => ['No Data'],
        'ageRange' => [],
        'device' => [],
        'gender' => [],
        'locations' => [],
        'inventories' => [],
        'cohorts' => [],
      ];
    }
    // return $data['report'];
    // Append additional data
    $data['campaigns'] = Campaign::where('status', 'active')->get();
    $data['locations'] = Location::all();
    $data['filters'] = Filter::where('parent_id', null)
      ->where('child', 0)
      ->with('filter_values')
      ->get();

    $data['selectedCampaign'] = Campaign::find($request->input('campaign')) ?? '';
    $data['selectedlocation'] = Location::find($request->input('location')) ?? '';
    $data['selectedGender'] = $request->gender ?? '';
    $data['selectedAgeRange'] = $request->age_range ?? '';
    $data['selectedDevice'] = $request->device ?? '';
    // return $data;
    return view('content.pages.analytics.index', $data);
  }

  public function testcron(Request $request)
  {
    $now = Carbon::now();
    $targetHour = $now->copy()->subHour(); // One hour before now
    $targetDate = $targetHour->toDateString(); // 'YYYY-MM-DD'
    $hourIndex = $targetHour->hour; // 0 to 23

    $campaigns = Campaign::whereDate('start_date', '<=', $targetDate)
      ->whereDate('end_date', '>=', $targetDate)
      ->get();

    foreach ($campaigns as $campaign) {
      $projectionDetails = json_decode($campaign->projection_details, true);
      $totalImpressions = $campaign->impressions;

      if (!isset($projectionDetails[$targetDate])) {
        continue;
      }

      $dayData = $projectionDetails[$targetDate];
      $dayPercent = $dayData['percentage'] ?? 0;
      $hourPercent = $dayData['hourlyPercentages'][$hourIndex] ?? 0;

      $dayImpressions = $totalImpressions * ($dayPercent / 100);

      if (!isset($dayData['hourlyPercentages'][$hourIndex])) {
        continue;
      }

      // Total impressions to log for this hour
      $hourlyImpressions = round($dayImpressions * ($hourPercent / 100));

      // Breakdown data
      $genders = $campaign->gender ?? [];
      $locations = $campaign->locations ?? [];
      $filters = $campaign->filtervalues ?? [];
      $divisions = $campaign->division_value ?? [];

      if (empty($genders)) {
        $genders = [0 => 0];
      } else {
        foreach ($genders as $key => $value) {
          $genders[$key] = ceil(($value * $hourlyImpressions) / 100);
        }
      }
      if (empty($locations)) {
        $locations = [0 => 0];
      } else {
        foreach ($locations as $key => $value) {
          $locations[$key] = ceil(($value * $hourlyImpressions) / 100);
        }
      }
      if (empty($filters)) {
        $filters = [0 => 0];
      } else {
        foreach ($filters as $filter => $filter_value) {
          foreach ($filter_value as $key => $value) {
            $filters[$filter][$key] = ceil(($value * $hourlyImpressions) / 100);
          }
        }
      }
      if (empty($divisions)) {
        $divisions = [0 => 0];
      } else {
        foreach ($divisions as $division => $division_value) {
          foreach ($division_value as $key => $value) {
            $divisions[$division][$key] = ceil(($value * $hourlyImpressions) / 100);
          }
        }
      }

      $clicks = round($hourlyImpressions * ($campaign->ctr / 100)) + 5;
      $videoViews = round($hourlyImpressions * ($campaign->vtr / 100)) + 5;

      $campaign->creatives = $campaign->creatives
        ->map(function ($creative) use ($hourlyImpressions) {
          return [
            $creative->id => round($hourlyImpressions * ($creative->percentage / 100)) + 6,
          ];
        })
        ->toArray();

      $report = ReportLog::create([
        'campaign_id' => $campaign->id,
        'report_type' => 'hourly',
        'impressions' => $hourlyImpressions,
        'clicks' => $clicks,
        'video_views' => $videoViews,
        'locations' => $locations,
        'gender' => $genders,
        'filter_values' => $filters,
        'division_values' => $divisions,
        'creatives' => $campaign->creatives,
        'created_at' => now(),
        'updated_at' => now(),
      ]);

      return response()->json([
        'data' => $report,
        'status' => 'success',
        'message' => 'Hourly report logged successfully.',
      ]);
    }
  }
}
